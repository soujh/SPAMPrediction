from django import forms

class Mail(forms.Form):
   mail = forms.CharField(widget=forms.Textarea,label="Please enter un mail and click on 'Predict'")
      
        