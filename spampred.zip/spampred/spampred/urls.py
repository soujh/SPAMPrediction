from django.views.generic.base import TemplateView
from django.contrib import admin
from django.urls import path
from prediction.views import mail_view

urlpatterns = [
    path('admin/', admin.site.urls),
    path("", TemplateView.as_view(template_name="home.html"), name="home"),
    path("prediction/",mail_view,name='prediction'),
]
